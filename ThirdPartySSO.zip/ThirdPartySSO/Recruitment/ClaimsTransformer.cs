﻿//using Microsoft.AspNetCore.Authentication;
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Security.Claims;
//using System.Text.Json;
//using System.Threading.Tasks;

//namespace Recruitment
//{
//    public class DevClaimsTransformer : IClaimsTransformation
//    {
//        private static Dictionary<string, List<DevClaim>> devRoleClaims;

//        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
//        {
//            if (devRoleClaims == null)
//            {
//                devRoleClaims =
//                    JsonSerializer.Deserialize<Dictionary<string, List<DevClaim>>>(
//                        File.ReadAllText("dev-claims.json"));
//            }

//            var identity = (ClaimsIdentity)(principal?.Identity ?? throw new ArgumentNullException(nameof(principal)));
//            if (identity.IsAuthenticated)
//            {
//                foreach (var rc in devRoleClaims)
//                {
//                    foreach (var c in rc.Value)
//                    {
//                        if (c.Active)
//                        {
//                            identity.AddClaim(new Claim(rc.Key, c.Claim));
//                        }
//                    }
//                }
//            }

//            return new ClaimsPrincipal(identity);
//        }

//        private class DevClaim
//        {
//            public string Claim { get; set; }

//            public bool Active { get; set; }
//        }
//    }
//}
