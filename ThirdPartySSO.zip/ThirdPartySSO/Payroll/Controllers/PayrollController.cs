﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Payroll.Models;

namespace Payroll.Controllers
{
   //[ Authorize]
    public class PayrollController : Controller
    {
        private readonly ILogger<PayrollController> _logger;

        public PayrollController(ILogger<PayrollController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ViewData["Claim"]  = TempData["Claim"] as string; 
           
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
